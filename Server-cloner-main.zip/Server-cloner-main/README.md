# Discord Server Cloner
- An efficient tool to clone Discord server without having any need of admin priveleges.

## Features
- **No Admin Privileges Needed**: Clone servers without requiring admin rights.
- **Full Server Replication**: Copy channels, roles, categories, and other server settings.
- **User-Friendly**: Simple interface and easy to follow prompts.
- **Customizable Cloning**: Choose whether to include server emojis in the clone.

## Installation & Usage
1. Download the repository and extract the files.
2. Run the `install.bat` file to install all necessary Python packages.
3. Follow the on screen instructions to provide your Discord token and server IDs.
4. The tool will guide you through the cloning process.

